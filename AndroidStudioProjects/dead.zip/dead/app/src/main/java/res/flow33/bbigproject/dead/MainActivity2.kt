package res.flow33.bbigproject.dead

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val button = findViewById<Button>(R.id.menuButton)
        setContentView(R.layout.activity_add)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            insets
        }
        button.setOnClickListener {
            showPopupMenu(it)
        }
    }
    private fun showPopupMenu(anchor: android.view.View) {
        val popupMenu = PopupMenu(this, anchor)

        popupMenu.menuInflater.inflate(R.menu.popup_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { item: MenuItem ->
            when (item.itemId) {
                R.id.option1 -> {
                    showToast("옵션 1 선택됨")
                    true
                }
                R.id.option2 -> {
                    showToast("옵션 2 선택됨")
                    true
                }
                R.id.option3 -> {
                    showToast("옵션 3 선택됨")
                    true
                }
                else -> false
            }
        }
        popupMenu.show()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}