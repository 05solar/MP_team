package com.STEP_UP_Project.Kms

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.STEP_UP_Project.Kms.R

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_settings) // 관련 레이아웃 파일
    }
}
